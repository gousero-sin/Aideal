# goflow-core

Pacote separado do nucleo do GoFlowOS para reutilizacao em outros projetos React.

## O que inclui

- `engine/useFlowState`
- `theme/ThemeContext`
- `ui/HydroComponents`
- `ui/HydroBackground`
- `ui/ShellStream`
- `ui/GlacierFS`

## Instalacao

```bash
npm install
npm run build
```

## Uso basico

```jsx
import {
  ThemeProvider,
  useFlowState,
  FlowContainer,
  CurrentButton,
  HydroBackground
} from 'goflow-core';

function Example() {
  const flow = useFlowState('ok');

  return (
    <ThemeProvider>
      <HydroBackground />
      <FlowContainer flowState={flow.flowState}>
        <CurrentButton onClick={() => flow.transition('novo estado')}>
          Transicao
        </CurrentButton>
      </FlowContainer>
    </ThemeProvider>
  );
}
```

## Observacao

Os componentes usam classes utilitarias no estilo Tailwind. Para o visual completo, o projeto consumidor precisa ter utilitarios equivalentes.
